from sst import UnitAlgebra
import random

# Parameters used in the Example configuration

## NOTE: The application and arguments to simulate should be passed via either
## a commandline argument to example.py or by setting the VANADIS_EXE and VANADIS_EXE_ARGS 
## environment variables. They are not set in this file.

# --------------------------------------------#
### General System                          ###
# --------------------------------------------#

core_count = 24
core_frequency = "3.1GHz"
uncore_frequency = "2.2GHz"
cache_coherence = "mesi"
cache_line_size = UnitAlgebra("64B")
memory_capacity = UnitAlgebra("256GiB")
page_size = UnitAlgebra("4096B")
layout = "5x5" # This is the layout of the mesh
line_header_size = "8B" # sizeof the header (address + metadata) for a request/response
debug_addresses = [] # No impact unless SST configured with --enable-debug
                     # Leave empty to debug all addresses

# --------------------------------#
### Network-on-chip (NoC)       ###
# --------------------------------#
noc_buffer_depth = 2 # 2 is minimum
noc_bandwidth = "2.8TB/s"
noc_link_width = "256b"

# --------------------------------#
### Cores                       ###
# --------------------------------#
core_hw_threads = 1
core_reorder_slots = 64
core_physical_integer_registers = 128 # default
core_physical_fp_registers = 128 # default
core_integer_arith_units = 2 # default
core_integer_arith_cycles = 2 #default
core_integer_div_units = 1 #default
core_integer_div_cycles = 4 #default
core_fp_arith_units = 2 #default
core_fp_arith_cycles = 8 #default
core_fp_div_units = 1 #default
core_fp_div_cycles = 80 #default
core_branch_units = 1
core_branch_unit_cycles = core_integer_arith_cycles
core_branch_entries = 64
core_issues_per_cycle = 2
core_fetches_per_cycle = 2
core_retires_per_cycle = 2
core_decodes_per_cycle = 2
core_uop_entries = 128
core_predecode_cache_entries = 4
core_lsq_stores = 10 # max_stores in store queue
core_lsq_loads = 20 # max_loads in load queue
core_lsq_issues_per_cycle = 2 # Number of loads and stores issued per cycle
core_data_tlb_hit_latency = 0.5 # In ns
core_data_tlb_set_size = 4
core_data_tlb_entries_per_thread = 64
core_insn_tlb_hit_latency = 0.5 # In ns
core_insn_tlb_set_size = 4
core_insn_tlb_entries_per_thread = 64
core_min_virtual_address = 4096
core_max_virtual_address = 0x80000000

# The rest is for debugging if needed
core_verbose = 0
core_dbg_mask = 0
core_start_verbose_when_issue_address = ""
core_stop_verbose_when_retire_address = 0 # 0=None
core_pause_when_retire_address = 0 # 0=None
core_pipeline_trace_file = ""
core_exit_after_cycles = -1 # Exit after this many cycles (< 0 means ignore parameter)
core_print_retire_tables = False
core_print_issue_tables = False
core_print_int_reg = False
core_print_fp_reg = False
core_print_rob = False

# --------------------------------#
### L1 I-Cache                  ###
# --------------------------------#
l1icache_size = "64KiB"
l1icache_banks = 4
l1icache_associativity = 4
l1icache_tag_latency = 1
l1icache_latency = 3
l1icache_requests_per_cycle = 6
l1icache_request_bytes_per_cycle = "0B" # Let requests_per_cycle be the limiter
l1icache_response_bytes_per_cycle = "0B" # No limit on responses
l1icache_fill_buffers = 16
l1icache_fill_buffer_latency = 1
l1icache_replacement = "lru"
# These are for debug/error reporting
l1icache_timeout = 0 # No timeout
l1icache_debug_level = 0 # No impact unless SST configured with --enable-debug
l1icache_verbose = 1 # Basic warnings enabled

# --------------------------------#
### L1 I-Cache                  ###
# --------------------------------#
l1dcache_size = "64KiB"
l1dcache_banks = 4
l1dcache_associativity = 4
l1dcache_tag_latency = 1
l1dcache_latency = 3
l1dcache_requests_per_cycle = 4
l1dcache_request_bytes_per_cycle = "0B" # Let requests_per_cycle be the limiter
l1dcache_response_bytes_per_cycle = "0B" # No limit on response throughput
l1dcache_fill_buffers = 16
l1dcache_fill_buffer_latency = 1
l1dcache_replacement = "lru"
l1dcache_llsc_wait_cycles = l1dcache_latency + l1dcache_tag_latency + 2
                        # A LL will cause the cache to stall competing accesses for this many cycles
                        # Reduces chance of livelock
# These are for debug/error reporting
l1dcache_timeout = 0 # No timeout
l1dcache_debug_level = 0 # No impact unless SST configured with --enable-debug
l1dcache_verbose = 1 # Basic warnings enabled

# --------------------------------#
### L2 Cache                    ###
# --------------------------------#
l2cache_size = "512KiB"
l2cache_banks = 4
l2cache_associativity = 8
l2cache_tag_latency = 2
l2cache_latency = 8
l2cache_requests_per_cycle = 4
l2cache_request_bytes_per_cycle = "0B" # Let requests_per_cycle be the limiter
l2cache_response_bytes_per_cycle = "0B" # No limit on response throughput
l2cache_fill_buffers = 16
l2cache_fill_buffer_latency = 1
l2cache_replacement = "lru"
# These are for debug/error reporting
l2cache_debug_level = 0 # No impact unless SST configured with --enable-debug
l2cache_verbose = 1 # Basic warnings enabled

# --------------------------------#
### L3 Cache                    ###
# --------------------------------#
l3cache_count = 24
l3cache_size = "1MiB"
l3cache_banks = 8
l3cache_associativity = 8
l3cache_latency = 10
l3cache_tag_latency = 6
l3cache_requests_per_cycle = 8
l3cache_request_bytes_per_cycle = "0B" # Let requests_per_cycle be the limiter
l3cache_response_bytes_per_cycle = "0B" # No limit on response throughput
l3cache_fill_buffers = 24
l3cache_fill_buffer_latency = 1
l3cache_replacement = "lru"
# These are for debug/error reporting
l3cache_debug_level = 0 # No impact unless SST configured with --enable-debug
l3cache_verbose = 1 # Basic warnings enabled

# --------------------------------#
### Directory                   ###
# --------------------------------#
# In this config, the directory is co-located with L3
l3cache_dir_entries = (UnitAlgebra(l3cache_size) + UnitAlgebra(l2cache_size) + UnitAlgebra("512KB")) / cache_line_size
l3cache_dir_replacement = "lru"
l3cache_dir_associativity = 16

# --------------------------------#
### Memory                      ###
# --------------------------------#
memory_controller_clock = uncore_frequency
memory_backing = "malloc" # Allocate memory to hold simulated data on-demand
memory_initialize_to_zero = True
memory_type = "LPDDR5"

###########################################
################# STOP ####################
#### Modify parameters above this line ####
###########################################

###########################################
# Helper functions for configuration

# Removes the 'count' indices from connection_map. 
# Seed random before calling to make this deterministic.
def mask(connection_map : list, count : int, info=""):
    total = sum(connection_map)
    mask_set = random.sample(range(0,total), count)
    mask_set.sort()
    if info != "":
        print("Masked set for {}: {}".format(info, mask_set))

    index = 0
    value = connection_map[index]
    for x in mask_set:
        while x > value:
            index += 1
            value += connection_map[index]
        
        connection_map[index] -= 1
            
    return connection_map

###########################################
# Parameter sets for each component type
# Most parameters are determined using the variables above
noc_x, noc_y = map(int, layout.split('x'))
mesh_stops = noc_x * noc_y

noc_bisection_links = max(noc_x, noc_y)
noc_link_bandwidth = UnitAlgebra(noc_bandwidth) / UnitAlgebra(noc_bisection_links)
# For 256b channel, data flit will be 36B (64B or 256b data + 4B of the header)
byte_convert = UnitAlgebra("8b/B")
if UnitAlgebra(noc_link_width).hasUnits("b"):
    noc_link_width_bytes = UnitAlgebra(noc_link_width) / byte_convert
else:
    noc_link_width_bytes = UnitAlgebra(noc_link_width)
data_flits_per_line = cache_line_size / noc_link_width_bytes
header_per_data_flit = UnitAlgebra(line_header_size) / data_flits_per_line
noc_data_flit = noc_link_width_bytes + header_per_data_flit
noc_size = layout # Do not change without also modifying structures in example.py

core_params = {
    "hardware_threads": core_hw_threads,
    "clock" : core_frequency,
    "reorder_slots" : core_reorder_slots,
    "physical_integer_registers" : core_physical_integer_registers,
    "physical_fp_registers" : core_physical_fp_registers,
    "integer_arith_units" : core_integer_arith_units,
    "integer_arith_cycles" : core_integer_arith_cycles,
    "integer_div_units" : core_integer_div_units,
    "integer_div_cycles" : core_integer_div_cycles,
    "fp_arith_units" : core_fp_arith_units,
    "fp_arith_cycles" : core_fp_arith_cycles,
    "fp_div_units" : core_fp_div_units,
    "fp_div_cycles" : core_fp_div_cycles,
    "branch_units": core_branch_units,
    "branch_unit_cycles": core_branch_unit_cycles,
    "issues_per_cycle": core_issues_per_cycle,
    "fetches_per_cycle": core_fetches_per_cycle,
    "retires_per_cycle": core_retires_per_cycle,
    "decodes_per_cycle": core_decodes_per_cycle,
    "dcache_line_width": cache_line_size.getRoundedValue(),
    "icache_line_width": cache_line_size.getRoundedValue(),
    "print_retire_tables": core_print_retire_tables,
    "print_issue_tables": core_print_issue_tables,
    "print_int_reg": core_print_int_reg,
    "print_fp_reg": core_print_fp_reg,
    "print_rob": core_print_rob,
    "enable_simt": False, # This parameter is not yet available in Vanadis
    "verbose": core_verbose,
    "dbg_mask": core_dbg_mask,
    "start_verbose_when_issue_address": core_start_verbose_when_issue_address,
    "stop_verbose_when_retire_address": core_stop_verbose_when_retire_address,
    "pause_when_retire_address": core_pause_when_retire_address,
    "pipeline_trace_file": core_pipeline_trace_file,
    "max_cycle": core_exit_after_cycles
}

os_params = {
    "cores" : core_count,
    "hardwareThreadCount" : core_hw_threads,
    "physMemSize" : memory_capacity,
    "page_size" : page_size.getRoundedValue(),
    "useMMU" : True,
}

branch_unit_params = { "branch_entries" : core_branch_entries }

decoder_params = {
    "icache_line_width" : cache_line_size.getRoundedValue(),
    "uop_cache_entries" : core_uop_entries,
    "predecode_cache_entries" :  core_predecode_cache_entries, # Number of cache lines to store
    "decode_max_ins_per_cycle" : core_decodes_per_cycle,
    "loader_mode" : 0 # Use LRU instead of infinite cache
}

lsq_params = {
    "max_stores" : core_lsq_stores,
    "max_loads" : core_lsq_loads,
    "issues_per_cycle" : core_lsq_issues_per_cycle,
    "cache_line_width" : cache_line_size.getRoundedValue()
}

dtlb_params = {
    "hitLatency" : core_data_tlb_hit_latency,
    "num_hardware_threads" : core_hw_threads,
    "num_tlb_entries_per_thread" : core_data_tlb_entries_per_thread,
    "tlb_set_size" : core_data_tlb_set_size,
    "minVirtAddr" : core_min_virtual_address,
    "maxVirtAddr" : core_max_virtual_address
}

itlb_params = {
    "hitLatency" : core_insn_tlb_hit_latency,
    "num_hardware_threads" : core_hw_threads,
    "num_tlb_entries_per_thread" : core_insn_tlb_entries_per_thread,
    "tlb_set_size" : core_insn_tlb_set_size,
    "minVirtAddr" : core_min_virtual_address,
    "maxVirtAddr" : core_max_virtual_address
}

if l1icache_debug_level > 0:
    l1icache_do_debug = 1
else:
    l1icache_do_debug = 0
l1i_params = {
    "L1" : 1,
    "cache_type" : "inclusive", # All L1s must be inclusive
    "cache_size" : l1icache_size,
    "cache_line_size" : cache_line_size.getRoundedValue(),
    "banks" : l1icache_banks,
    "associativity" : l1icache_associativity,
    "coherence_protocol" : cache_coherence,
    "cache_frequency" : core_frequency,
    "access_latency_cycles" : l1icache_latency,
    "tag_access_latency_cycles" : l1icache_tag_latency,
    "max_requests_per_cycle" : l1icache_requests_per_cycle,
    "request_link_width" : l1icache_request_bytes_per_cycle,
    "response_link_width" : l1icache_response_bytes_per_cycle,
    "mshr_num_entries": l1icache_fill_buffers,
    "mshr_latency_cycles" : l1icache_fill_buffer_latency,
    "min_packet_size" : line_header_size,
    "maxRequestDelay" : l1icache_timeout,
    "debug" : l1icache_do_debug,
    "debug_level" : l1icache_debug_level,
    "debug_addr" : debug_addresses,
    "verbose" : l1icache_verbose,
    # Don't have a prefetcher, but if we did, should enable these
    #"prefetch_delay_cycles" : l1icache_prefetch_latency,
    #"max_outstanding_prefetch" : l1icache_max_concurrent_prefetches,
    #"drop_prefetch_mshr_level" : l1icache_max_prefetch_fill_buffers,   
}

if l1dcache_debug_level > 0:
    l1dcache_do_debug = 1
else:
    l1dcache_do_debug = 0
l1d_params = {
    "L1" : 1,
    "cache_type" : "inclusive", # All L1s must be inclusive
    "cache_size" : l1dcache_size,
    "banks" : l1dcache_banks,
    "cache_line_size" : cache_line_size.getRoundedValue(),
    "associativity" : l1dcache_associativity,
    "coherence_protocol" : cache_coherence,
    "cache_frequency" : core_frequency,
    "access_latency_cycles" : l1dcache_latency,
    "tag_access_latency_cycles" : l1dcache_tag_latency,
    "max_requests_per_cycle" : l1dcache_requests_per_cycle, 
    "mshr_num_entries" : l1dcache_fill_buffers,
    "mshr_latency_cycles" : l1dcache_fill_buffer_latency,
    "llsc_block_cycles" : l1dcache_llsc_wait_cycles,
    "min_packet_size" : line_header_size,
    "max_requests_per_cycle" : l1dcache_requests_per_cycle,
    "request_link_width" : l1dcache_request_bytes_per_cycle,
    "response_link_width" : l1dcache_response_bytes_per_cycle,
    "maxRequestDelay" : l1dcache_timeout,
    "debug" : l1dcache_do_debug,
    "debug_level" : l1dcache_debug_level,
    "debug_addr" : debug_addresses,
    "verbose" : l1dcache_verbose,
    # Don't have a prefetcher, but if we did, should enable these
    #"prefetch_delay_cycles" : l1dcache_prefetch_latency,
    #"max_outstanding_prefetch" : l1dcache_max_concurrent_prefetches,
    #"drop_prefetch_mshr_level" : l1dcache_max_prefetch_fill_buffers,   
}

if l2cache_debug_level > 0:
    l2cache_do_debug = 1
else:
    l2cache_do_debug = 0
l2_params = {
    "cache_type" : "inclusive",
    "cache_size" : l2cache_size,
    "banks" : l2cache_banks,
    "cache_line_size" : cache_line_size.getRoundedValue(),
    "associativity" : l2cache_associativity,
    "coherence_protocol" : cache_coherence,
    "cache_frequency" : core_frequency,
    "access_latency_cycles" : l2cache_latency,
    "tag_access_latency_cycles" : l2cache_tag_latency,
    "max_requests_per_cycle" : l2cache_requests_per_cycle, 
    "mshr_num_entries" : l2cache_fill_buffers,
    "mshr_latency_cycles" : l2cache_fill_buffer_latency,
    "min_packet_size" : line_header_size,
    "max_requests_per_cycle" : l2cache_requests_per_cycle,
    "request_link_width" : l2cache_request_bytes_per_cycle,
    "response_link_width" : l2cache_response_bytes_per_cycle,
    "debug" : l2cache_do_debug,
    "debug_level" : l2cache_debug_level,
    "debug_addr" : debug_addresses,
    "verbose" : l2cache_verbose,
    # Don't have a prefetcher, but if we did, should enable these
    #"prefetch_delay_cycles" : l2cache_prefetch_latency,
    #"max_outstanding_prefetch" : l2cache_max_concurrent_prefetches,
    #"drop_prefetch_mshr_level" : l2cache_max_prefetch_fill_buffers,  
}

if l3cache_debug_level > 0:
    l3cache_do_debug = 1
else:
    l3cache_do_debug = 0
l3_params = {
    "cache_type" : "noninclusive_with_directory",
    "cache_size" : l3cache_size,
    "banks" : l3cache_banks,
    "cache_line_size" : cache_line_size.getRoundedValue(),
    "associativity" : l3cache_associativity,
    "noninclusive_directory_entries" : l3cache_dir_entries,
    "noninclusive_directory_associativity": l3cache_dir_associativity,
    "coherence_protocol" : cache_coherence,
    "cache_frequency" : uncore_frequency,
    "access_latency_cycles" : l3cache_latency,
    "tag_access_latency_cycles" : l3cache_tag_latency,
    "max_requests_per_cycle" : l3cache_requests_per_cycle, 
    "mshr_num_entries" : l3cache_fill_buffers,
    "mshr_latency_cycles" : l3cache_fill_buffer_latency,
    "min_packet_size" : line_header_size,
    "max_requests_per_cycle" : l3cache_requests_per_cycle,
    "request_link_width" : l3cache_request_bytes_per_cycle,
    "response_link_width" : l3cache_response_bytes_per_cycle,
    "debug" : l3cache_do_debug,
    "debug_level" : l3cache_debug_level,
    "debug_addr" : debug_addresses,
    "verbose" : l3cache_verbose,
    # Don't have a prefetcher, but if we did, should enable these
    #"prefetch_delay_cycles" : l3cache_prefetch_latency,
    #"max_outstanding_prefetch" : l3cache_max_concurrent_prefetches,
    #"drop_prefetch_mshr_level" : l3cache_max_prefetch_fill_buffers,  
}

memory_controller_params = {
    "clock" : memory_controller_clock,
    "backing" : memory_backing,
    "initBacking" : memory_initialize_to_zero
}
