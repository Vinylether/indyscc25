import sst
import os
import sys
import random
# A little hacky but does the trick
sys.path.append("./arch")
from vanadislib import *
from mhlib import *
from kinglib import *
from example_params import *

### USAGE ###
# The following files need to be in the same directory:
# - example_params.py
# - mhlib.py
# - vanadislib.py
# - kinglib.py
# Specify the application to run using by passing as a command line argument, e.g.,
# sst example.py -- app.exe arg0 arg1
# OR pass in through the VANADIS_EXE and VANADIS_EXE_ARGS env variables

### OUTPUT ###
# The expected output of this script is as follows:
# - stdout-100 : Any output to stdout produced by the app running on the simulated hardware
# - stderr-100 : Any output to stderr produced by the app running on the simulated hardware
# - StatisticsOuput.csv : Statistics output from the simulation. The name/filepath can be modified if desired.
# - Output to stdout that looks like the following. Simulation time will vary depending on the application you simulate.
#   Masked set will vary depending on the random seed in this script.
#
#   $ sst example.py -- small/basic-io/hello-world/riscv64/hello-world 
#     Masked set for cores: [4]
#     Masked set for l3caches: [14]
#     Python configuration is finished
#     pid=100 tid=100 has exited
#     all process have exited
#     Simulation is complete, simulated time: 8.93741 us

### Guidelines for modification ###
# - Generally, parameters above the 'STOP' line in example_params.py can be modified.
# - The random seed below can be modified.
# - The connectivity maps below determine which mesh stops on the NoC, each core complex, l3 slice,
#   and memory are connected to. Each index corresponds to a mesh stop and its value indicates how 
#   many objects of that type are connected there. 
#       - 'memory_connection_map' can be modified to change layout and/or number of memory channels. 
#       - More than one object may be connected at a mesh stop by putting a larger number in the corresponding
#         index (e.g., core_connection_map = [2] * mesh_stops would allow up to 2 cores per mesh stop)
# - Modify where the Vanadis OS core lives on the mesh by changing the os_router parameter in the 
#   connectVanadisCores() function below
# - If the 'layout' parameter in example_params.py is modified, the memory_connection_map below
#   mush also be correspondingly modified.
# - Modify the statistics output parameters below to change the file type/name

### Script Starts Here

# This configuration uses a random selection of inoperable cores and caches
random.seed(100) # Ensure the selection of disabled cores/caches is reproducible

# Get application and any parameters
app_args = []
if len(sys.argv) > 1:
    app = sys.argv[1]
    if len(sys.argv) > 2:
        app_args = sys.argv[2:]
else:
    app = os.getenv("VANADIS_EXE", "")
    app_args = os.getenv("VANADIS_EXE_ARGS", "").split()
    if app == "":
        print("Error: This script requires an application for vanadis to run\n"
              "Either set the VANADIS_EXE and if needed, VANADIS_EXE_ARGS environment variables\n"
              "or, pass the application as command line arguments to this script such as\n"
              "'$ sst example.py -- app.x arg0 arg1'\n")
        sys.exit()

# Check the layout and randomly select cores/caches to be disabled if needed
core_connection_map = [1] * mesh_stops
if core_count > mesh_stops:
    print("Error: The configuration has fewer mesh stops than cores. stops={}, cores={}".format(mesh_stops, core_count))
    print("Modify the 'core_count' and/or 'layout' parameters in example_params.py")
    sys.exit(1)
inoperable_core_count = sum(core_connection_map) - core_count
masked_core_map = mask(core_connection_map, inoperable_core_count, "cores")

# Disable L3 slices if mesh stops > l3cache_count
l3_connection_map = [1] * mesh_stops
if l3cache_count > mesh_stops:
    print("Error: The configuration has fewer mesh stops than l3 caches. stops={}, l3s={}".format(mesh_stops, l3cache_count))
    print("Modify the 'l3cache_count' and/or 'layout' parameters in example_params.py")
inoperable_l3_count = sum(l3_connection_map) - l3cache_count
masked_l3_map = mask(l3_connection_map, inoperable_l3_count, "l3caches")

# Determine where memory will be connected on the mesh
# The number of memories can be modified by changing this map
# If 'layout' in example_params.py is modified, this map MUST be modified as well
memory_connection_map = [
  0, 1, 0, 1, 0,
  0, 0, 0, 0, 0,
  0, 0, 0, 0, 0,
  0, 0, 0, 0, 0,
  0, 1, 0, 1, 0 ]
memory_channels = sum(memory_connection_map)

if len(memory_connection_map) != mesh_stops:
    print("Error: modify the memory_connection_map so that its length matches the number of mesh stops available ({})".format(mesh_stops))


# Create the cores
multicore = Vanadis("core", core_count, core_frequency)
multicore.configureCores(core_params)
multicore.configureDecoders(decoder_params)
multicore.configureBranchUnits(branch_unit_params)
multicore.configureLoadStoreQueues(lsq_params)
multicore.configureOperatingSystem(os_params)
multicore.configureTLBs(dtlb_params, dtlb=True)
multicore.configureTLBs(itlb_params, dtlb=False)
multicore.configureApplication(app, app_args=app_args)

# Add the private caches to cores to create a core complex
multicore.addPrivateL1L2(l1i_params, l1d_params, l2_params)
multicore.getL1ICaches().setReplacement(l1icache_replacement)
multicore.getL1DCaches().setReplacement(l1dcache_replacement)
multicore.getL2Caches().setReplacement(l2cache_replacement)

# Create L3s
l3 = DistributedL3("l3cache", l3cache_count, l3_params)
l3.setReplacement(l3cache_replacement, for_directory=False)
l3.setReplacement(l3cache_dir_replacement, for_directory=True)

# Create memory
memories = InterleavedMemory("memory", memory_channels, memory_capacity, interleave_size=page_size)
memories.setTimingModelToSimpleDRAM(memory_type)
memories.configureControllers(memory_controller_params)

## Set up the NoC and connect all the pieces together

noc = KingsleyMesh("mesh", noc_x, noc_y, 
                   frequency=uncore_frequency,
                   data_flit_size = noc_data_flit,
                   ctrl_flit_size = line_header_size,
                   nic_input_buffer_entries=noc_buffer_depth,
                   nic_output_buffer_entries=noc_buffer_depth,
                   router_buffer_entries=noc_buffer_depth)

# Connect cores and OS cache to NoC
## Vanadis models the OS as a process on its own dedicated core (in addition to the 'normal' cores)
## Connect it to mesh_stop 0 (os_router=0)
noc.connectVanadisCores(multicore, masked_core_map, os_router=0)

# Connect L3s to NoC
noc.connectDistributedCache(l3, masked_l3_map)

# Connect memories to NoC
noc.connectMemory(memories, memory_connection_map)

# Finish configuration of the NoC
noc.finalize()

# Enable statistics everywhere, write to CSV
# Modify this configuration to send output to a different format or print more/less often
sst.setStatisticLoadLevel(7)
sst.enableAllStatisticsForAllComponents()
sst.setStatisticOutput("sst.statOutputCSV", {"filepath" : "StatisticOutput.csv"})

print("Python configuration is finished")
