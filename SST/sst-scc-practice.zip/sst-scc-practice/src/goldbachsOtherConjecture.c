#include <stdbool.h>
#include <stdio.h>

bool isPrime(int num)
{
    if (num <= 1)
    {
        return false;
    }
    else
    {
        for (int i = 2; i * i <= num; i++)
        {
            if (num % i == 0)
            {
                return false;
            }
        }

        return true;
    }
}


bool testGoldbachOther(int num)
{
    if (num % 2 == 0)
    {
        return false;
    }
    else
    {
        for (int i = 0; 2 * (i * i) < num - 2; i++)
        {
            int diff = num - (2 * (i * i));
            if (isPrime(diff))
            {
                return true;
            }

        }
    }

    return false;
}

int main()
{
    int failureFound = false;
    int possibleComposite = 9;
    while (!failureFound && possibleComposite < 10000)
    {
        if (!isPrime(possibleComposite))
        {
            if (!testGoldbachOther(possibleComposite))
            {
                printf("Found failure case: %d\n", possibleComposite);
                failureFound = true;
            }
        }

        possibleComposite += 2;
    }
}