#include <stdlib.h>
#include <stdio.h>
#include <omp.h>
#include <math.h>
#include <string.h>

int main(int argc, char* argv[]) 
{
    int threads;
    if (argc == 2)
    {
        threads = atoi(argv[1]);
        printf("Using %d threads\n", threads);
    }
    else
    {
        printf("Using default num threads\n");
        threads = 1;
    }

    omp_set_num_threads(threads);

    int size = 1000000;
    double* first = (double*) malloc(size * sizeof(double));
    double* second = (double*) malloc(size  * sizeof(double));
    double* sum = (double*) calloc(size, sizeof(double));
    for (int i = 0; i < size; i++)
    {
        first[i] = sin(i) * tan(i / 2);
        second[i] = (1 - cos(i)) / 2;
    }

    int i;
    #pragma omp parallel for shared(first, second, sum, size) private(i) schedule(static)
    for (i = 0; i < size; i++)
    {
        sum[i] = first[i] + second[i];
    }

    printf("Spot check: %f %f %f\n", sum[0], sum[500000], sum[size - 1]);

    free(first);
    free(second);
    free(sum);
}