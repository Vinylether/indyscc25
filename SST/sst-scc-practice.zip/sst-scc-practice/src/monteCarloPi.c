#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() 
{
    double diameter = 32.0;
    double radius = diameter / 2.0;
    int inCircle = 0;
    int numIterations = 1000; // Can we get this as input w/vanadis?
    srand(time(NULL));
    for (int i = 0; i < numIterations; i++)
    {
        double xRandom = (double) rand() / (double) RAND_MAX;
        double xValue = (xRandom - 0.5) * diameter;

        double yRandom = (double) rand() / (double) RAND_MAX;
        double yValue = (yRandom - 0.5) * diameter;
        
        double distanceFromOrigin = sqrt(xValue * xValue + yValue * yValue);
        if (distanceFromOrigin <= radius)
        {
            inCircle++;
        }
    }

    printf("Points in circle: %d\n", inCircle);
    double estimatedPi = 4.0 * (double) inCircle / (double) numIterations;
    printf("Estimatd Pi: %.10f, Error: %.10f\n", estimatedPi, fabs(estimatedPi - M_PI));
}